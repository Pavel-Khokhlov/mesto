const params = {
  formSelector: ".popup__container",
  inputSelector: ".popup__input",
  submitButtonSelector: ".popup__save-btn",
  inactiveButtonClass: "popup__save-btn_inactive",
  activeErrorClass: "popup__input-error_active",
  inputInvalidClass: "popup__input_invalid",
};
