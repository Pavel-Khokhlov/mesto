const initialPlaces = [
  {
    name: "Штаб квартира",
    link: "./images/lmaranello.jpg",
  },
  {
    name: "Феррари парк",
    link: "./images/ferrariworld.jpg",
  },
  {
    name: "Ferrari 812",
    link: "./images/812superfast.jpg",
  },
  {
    name: "Команда Formula-1",
    link: "./images/formula1.jpg",
  },
  {
    name: "Михаэль Шумахер",
    link: "./images/schumacher.jpg",
  },
  {
    name: "Museo Ferrari",
    link: "./images/museo.jpg",
  },
];
